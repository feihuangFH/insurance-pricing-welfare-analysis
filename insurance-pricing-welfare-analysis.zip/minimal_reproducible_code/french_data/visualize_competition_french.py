#!/usr/bin/env python
# coding: utf-8

# In[1]:


import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
from matplotlib.patches import Rectangle
# from utils import *
import numpy as np
import seaborn as sns
# import causallearn.utils.cit as cit
# import causallearn.utils.KCI.KCI as kci

import plotly.graph_objects as go
from plotly import offline

import warnings
warnings.filterwarnings('ignore')

plt.rcParams.update({'font.size': 14})


# In[2]:


#No insurance case.
result_dir = 'results_French_uninsured_all_prices'

df_summary_noins = pd.read_csv(f'{result_dir}/welfare_result_summary.csv',index_col=0)
df_summary_noins.set_index('model',inplace=True)
df_ind_noins = pd.read_csv(f'{result_dir}/welfare_result_individual.csv',index_col=0)

df_traditional =pd.read_csv('French_individual_traditional.csv',index_col=0)
df_ind_noins = df_ind_noins.merge(df_traditional,left_index=True,right_index=True)
n_consumer = len(df_ind_noins)


models = df_summary_noins.index
base_model = 'C0-P0'
cost_only_models = [m for m in models if 'P0' in m]
price_only_models = [m for m in models if 'C0' in m]
joint_models = [m for m in models if ( ('P0' not in m) and ('C0' not in m) )]


# In[3]:


# Varying competitiveness of the market.
comp_param_list = [0.5, 1.0, 3.0]
df_summary_list = []
df_ind_list = []
for comp_param in comp_param_list:
    result_dir = f'results_French_mc_times_markup_{comp_param}_all_prices'# f'results_French_outside_option{comp_param}'
    # result_dir = 'results_French_no_ins_as_outside_option'

    df_summary = pd.read_csv(f'{result_dir}/welfare_result_summary.csv',index_col=0)
    df_summary.set_index('model',inplace=True)
    
    df_ind = pd.read_csv(f'{result_dir}/welfare_result_individual.csv',index_col=0)
    df_traditional =pd.read_csv('French_individual_traditional.csv',index_col=0)
    df_ind = df_ind.merge(df_traditional,left_index=True,right_index=True)    
    df_ind_list.append(df_ind)

    #Measure welfare as change from no-insurance state
    df_summary['welfare_gain0'] =  df_summary['welfare0']-df_summary['welfare0_no_insurance']
    df_summary['welfare_gain1'] =  df_summary['welfare1']-df_summary['welfare1_no_insurance']
    df_summary['welfare_gain'] =  df_summary['welfare']-df_summary['welfare_no_insurance']
    for model in models:
        df_ind[model+'_welfare_gain'] =  df_ind[model+'_welfare'] - df_ind['ce_no_insurance']


    for model in models:    
        df_temp = df_ind[['s','C0-P0_estimated_cost',f'{model}_price',f'{model}_welfare_gain']]
        df_temp['cost_price_ratio'] = (df_temp['C0-P0_estimated_cost']+.01)/(df_temp[f'{model}_price']+.01)
        df_temp['price_cost_ratio'] = (df_temp[f'{model}_price']+.01)/(df_temp['C0-P0_estimated_cost']+.01)
        df_male = df_temp.loc[df_ind['Gender_Male']==1]
        df_female = df_temp.loc[df_ind['Gender_Male']==0]
        df_summary.loc[model,'cost_price_ratio0'] = df_male.mean()['cost_price_ratio']
        df_summary.loc[model,'cost_price_ratio1'] = df_female.mean()['cost_price_ratio']
        df_summary.loc[model,'price_cost_ratio0'] = df_male.mean()['price_cost_ratio']
        df_summary.loc[model,'price_cost_ratio1'] = df_female.mean()['price_cost_ratio']

    df_summary_list.append(df_summary)
    



# In[4]:


markers = {}
colors = {}
filling = {}
#To create legends. https://stackoverflow.com/questions/45140295/how-to-create-a-legend-of-both-color-and-marker
# handles = [] 
# f = lambda m,c: plt.plot([],[],marker=m, color=c, ls="none")[0]
#Switched to https://stackoverflow.com/questions/47391702/how-to-make-a-colored-markers-legend-from-scratch

for m in models:
    if 'CU' in m:
        colors[m] = 'r'
    elif 'CDP' in m:
        colors[m] = 'g'
    elif 'CC' in m:
        colors[m] = 'b'
    else:
        colors[m] = 'k'
        
    if 'CA' in m:
        filling[m] = 'none'
    else:
        filling[m] = colors[m]
    
    if 'P0' in m:
        markers[m] = 'o'
    elif 'PA' in m:
        if 'PAF' in m:
            markers[m] = 'P'
        else:
            markers[m] = '^'
    elif 'POB' in m:
        markers[m] = 'v'
    elif 'PDP' in m:
        markers[m] = 's'


# unique_colors = ['lightgrey','salmon','lime','royalblue','k','r','g','navy']
# unique_colors = ['k','r','g','navy']
# unique_filling = ['none','k']
# unique_markers = ['o','^','v','s']


handles_c = []
handles_p = []
handles = []
cm_to_color = {'C0':'k','CU':'r','CDP':'g','CC':'b'}
pm_to_shape = {'P0':'o','PA':'^','POB':'v','PDP':'s','PAF':'P'}
am_to_fill = {'with CA':'none','w/o CA':'lightgray'}
for c_ in ['C0', 'CU','CDP', 'CC']:
    h_ = mlines.Line2D([], [], color=cm_to_color[c_], marker='o', linestyle='None',
                          markersize=10, label=c_)
    handles_c.append(h_)
    handles.append(h_)
for a_ in ['with CA', 'w/o CA']:
    h_ = mlines.Line2D([], [], color='lightgray', marker='*', linestyle='None',mfc=am_to_fill[a_],
                          markersize=10, label=a_)
    handles_c.append(h_)
    handles.append(h_)
for p_ in  ["P0", "PA", "POB", "PDP", "PAF"]:
    h_ = mlines.Line2D([], [], color='k', marker=pm_to_shape[p_], linestyle='None',
                          markersize=10, label=p_)
    handles_p.append(h_)
    handles.append(h_)
    



# handles = [f("s", unique_colors[i]) for i in range(4)]
# handles += [f("s", unique_filling[i]) for i in range(2)]
# handles += [f(unique_markers[i], "k") for i in range(4)]

# cost_labels = ['C0','CU','CDP','CC','CA','CA-CU','CA-CDP','CA-CC']
# cost_labels = ['C0','CU','CDP','CC']
# acc_labels = ['accountability', 'no accountability']
# price_labels = ["P0", "PA", "POB", "PDP"]
# labels = cost_labels+acc_labels + price_labels





# In[5]:


result_dir = 'competition_analysis_results'


# In[6]:


for df_summary  in df_summary_list:
    df_summary['welfare_change'] = (df_summary['welfare']-df_summary.loc['C0-P0','welfare'])/np.abs(df_summary.loc['C0-P0','welfare'])
    df_summary['profit_change'] = (df_summary['profit']-df_summary.loc['C0-P0','profit'])/np.abs(df_summary.loc['C0-P0','profit'])


# In[7]:


fig, ax = plt.subplots(1)
x=[comp-1. for comp in comp_param_list]
print(x)
for m in cost_only_models:
    y=[ df_summary.loc[m,'welfare_gain'] for df_summary in df_summary_list ]
    ax.plot(x,y
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)

ax.invert_xaxis()
ax.legend(handles=handles_c, bbox_to_anchor=(1.0, 1.0))
ax.set_xlabel('Outside option markup (competition level)')
ax.set_ylabel('Consumer welfare')
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_comp_vs_cw.pdf')


# In[8]:


fig, ax = plt.subplots(1)
x=[comp-1. for comp in comp_param_list]
print(x)
for m in cost_only_models:
    y=[ df_summary.loc[m,'welfare_change'] * 100 for df_summary in df_summary_list ]
    ax.plot(x,y
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)

ax.invert_xaxis()
ax.axhline(y=0, color='k', linestyle='--', alpha=0.5)
ax.legend(handles=handles_c, bbox_to_anchor=(1.0, 1.0))
ax.set_xlabel('Outside option markup (competition level)')
ax.set_ylabel('Consumer welfare change (relative to P0) (%)')
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_comp_vs_cw_r.pdf')


# In[9]:


fig, ax = plt.subplots(1)
for m in price_only_models:
    x=[comp-1. for comp in comp_param_list]
    y=[ df_summary.loc[m,'welfare_gain'] for df_summary in df_summary_list ]
    ax.plot(x,y
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)

ax.invert_xaxis()
ax.legend(handles=handles_p, bbox_to_anchor=(1.0, 1.0))
ax.set_xlabel('Outside option markup (competition level)')
ax.set_ylabel('Consumer welfare')
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_comp_vs_cw.pdf')


# In[10]:


fig, ax = plt.subplots(1)
for m in price_only_models:
    x=[comp-1. for comp in comp_param_list]
    y=[ df_summary.loc[m,'welfare_change'] * 100 for df_summary in df_summary_list ]
    ax.plot(x,y
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)

ax.invert_xaxis()
ax.axhline(y=0, color='k', linestyle='--', alpha=0.5)
ax.legend(handles=handles_p, bbox_to_anchor=(1.0, 1.0))
ax.set_xlabel('Outside option markup (competition level)')
ax.set_ylabel('Consumer welfare change (relative to P0) (%)', fontsize=12)
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_comp_vs_cw_r.pdf')


# In[11]:


fig, ax = plt.subplots(1)
for m in cost_only_models:
    x=[comp-1. for comp in comp_param_list]
    y=[ df_summary.loc[m,'profit'] for df_summary in df_summary_list ]
    ax.plot(x,y
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)

ax.invert_xaxis()
ax.set_xlabel('Outside option markup (competition level)')
ax.set_ylabel('Profit')
ax.legend(handles=handles_c, bbox_to_anchor=(1.0, 1.0))
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_comp_vs_profit.pdf')


# In[12]:


fig, ax = plt.subplots(1)
for m in cost_only_models:
    x=[comp-1. for comp in comp_param_list]
    y=[ df_summary.loc[m,'profit_change'] * 100 for df_summary in df_summary_list ]
    ax.plot(x,y
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)

ax.invert_xaxis()
ax.axhline(y=0, color='k', linestyle='--', alpha=0.5)
ax.set_xlabel('Outside option markup (competition level)')
ax.set_ylabel('Profit change (relative to P0) (%)')
ax.legend(handles=handles_c, bbox_to_anchor=(1.0, 1.0))
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_comp_vs_profit_r.pdf')


# In[13]:


fig, ax = plt.subplots(1)
for m in price_only_models:
    x=[comp-1. for comp in comp_param_list]
    y=[ df_summary.loc[m,'profit'] for df_summary in df_summary_list ]
    ax.plot(x,y
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)

ax.invert_xaxis()
ax.set_xlabel('Outside option markup (competition level)')
ax.set_ylabel('Profit')
ax.legend(handles=handles_p, bbox_to_anchor=(1.0, 1.0))
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_comp_vs_profit.pdf')


# In[14]:


fig, ax = plt.subplots(1)
for m in price_only_models:
    x=[comp-1. for comp in comp_param_list]
    y=[ df_summary.loc[m,'profit_change'] * 100 for df_summary in df_summary_list ]
    ax.plot(x,y
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)

ax.invert_xaxis()
ax.axhline(y=0, color='k', linestyle='--', alpha=0.5)
ax.set_xlabel('Outside option markup (competition level)')
ax.set_ylabel('Profit change (relative to P0) (%)')
ax.legend(handles=handles_p, bbox_to_anchor=(1.0, 1.0))
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_comp_vs_profit_r.pdf')


# In[15]:


fig, ax = plt.subplots(1)
for m in cost_only_models:
    x=[comp-1. for comp in comp_param_list]
    y=[df_summary.loc[m,'mean_price1']/df_summary.loc[m,'mean_price0'] -1. for df_summary in df_summary_list ]
    ax.plot(x,y
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
ax.set_xlabel('Outside option markup (competition level)')
ax.set_ylabel('Price gap (female/male)')
ax.invert_xaxis()
ax.legend(handles=handles_c, bbox_to_anchor=(1.0, 1.0))
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_comp_vs_price_gap.pdf')


# In[16]:


fig, ax = plt.subplots(1)
for m in price_only_models:
    x=[comp-1. for comp in comp_param_list]
    y=[df_summary.loc[m,'mean_price1']/df_summary.loc[m,'mean_price0'] -1. for df_summary in df_summary_list ]
    ax.plot(x,y
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
ax.set_xlabel('Outside option markup (competition level)')
ax.set_ylabel('Price gap (female/male)')
ax.invert_xaxis()
ax.legend(handles=handles_p, bbox_to_anchor=(1.0, 1.0))
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_comp_vs_price_gap.pdf')


# In[17]:


fig, ax = plt.subplots(1)
for m in cost_only_models:
    x=[comp-1. for comp in comp_param_list]
    y=[(df_summary.loc[m,'price_cost_ratio1']-1)/(df_summary.loc[m,'price_cost_ratio0']-1) -1. for df_summary in df_summary_list ]
    ax.plot(x,y
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
ax.set_xlabel('Outside option markup (competition level)')
ax.set_ylabel('Markup gap (female/male)')
ax.invert_xaxis()
ax.legend(handles=handles_c, bbox_to_anchor=(1.0, 1.0))
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_comp_vs_markup_gap.pdf')


# In[25]:


for df_summary in df_summary_list:
    df_summary['welfare_change0'] = (df_summary['welfare0']-df_summary.loc['C0-P0','welfare0'])/np.abs(df_summary.loc['C0-P0','welfare0'])
    df_summary['welfare_change1'] = (df_summary['welfare1']-df_summary.loc['C0-P0','welfare1'])/np.abs(df_summary.loc['C0-P0','welfare1'])

fig, ax = plt.subplots(1)
for m in cost_only_models:
    x=[comp-1. for comp in comp_param_list]
    y=[(df_summary.loc[m,'welfare_change0']) for df_summary in df_summary_list ]
    ax.plot(x,y
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
ax.set_xlabel('Outside option markup (competition level)')
ax.set_ylabel('Welfare change (male)')
ax.invert_xaxis()
ax.legend(handles=handles_c, bbox_to_anchor=(1.0, 1.0))
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_comp_vs_male_welfare_change.pdf')


# In[26]:


fig, ax = plt.subplots(1)
for m in cost_only_models:
    x=[comp-1. for comp in comp_param_list]
    y=[(df_summary.loc[m,'welfare_change1']) for df_summary in df_summary_list ]
    ax.plot(x,y
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
ax.set_xlabel('Outside option markup (competition level)')
ax.set_ylabel('Welfare change (female)')
ax.invert_xaxis()
ax.legend(handles=handles_c, bbox_to_anchor=(1.0, 1.0))
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_comp_vs_female_welfare_change.pdf')


# In[18]:


fig, ax = plt.subplots(1)
for m in price_only_models:
    x=[comp-1. for comp in comp_param_list]
    y=[(df_summary.loc[m,'price_cost_ratio1']-1)/(df_summary.loc[m,'price_cost_ratio0']-1) -1. for df_summary in df_summary_list ]
    ax.plot(x,y
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
ax.set_xlabel('Outside option markup (competition level)')
ax.set_ylabel('Markup gap (female/male)')
ax.legend(handles=handles_p, bbox_to_anchor=(1.0, 1.0))
ax.invert_xaxis()
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_comp_vs_markup_gap.pdf')


# In[28]:


for df_summary in df_summary_list:
    df_summary['welfare_change0'] = (df_summary['welfare0']-df_summary.loc['C0-P0','welfare0'])/np.abs(df_summary.loc['C0-P0','welfare0'])
    df_summary['welfare_change1'] = (df_summary['welfare1']-df_summary.loc['C0-P0','welfare1'])/np.abs(df_summary.loc['C0-P0','welfare1'])

fig, ax = plt.subplots(1)
for m in price_only_models:
    x=[comp-1. for comp in comp_param_list]
    y=[(df_summary.loc[m,'welfare_change0']) for df_summary in df_summary_list ]
    ax.plot(x,y
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
ax.set_xlabel('Outside option markup (competition level)')
ax.set_ylabel('Welfare change (male)')
ax.legend(handles=handles_p, bbox_to_anchor=(1.0, 1.0))
ax.invert_xaxis()
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_comp_vs_male_welfare_change.pdf')


# In[27]:


fig, ax = plt.subplots(1)
for m in price_only_models:
    x=[comp-1. for comp in comp_param_list]
    y=[(df_summary.loc[m,'welfare_change1']) for df_summary in df_summary_list ]
    ax.plot(x,y
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
ax.set_xlabel('Outside option markup (competition level)')
ax.set_ylabel('Welfare change (female)')
ax.legend(handles=handles_p, bbox_to_anchor=(1.0, 1.0))
ax.invert_xaxis()
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_comp_vs_female_welfare_change.pdf')


# In[19]:


for df_ind in df_ind_list:
    print(df_ind['C0-P0_coverage'].mean() )
# for df_ind in df_ind_list:
#     print(df_ind['ce_outside'].mean() )
for df_ind in df_ind_list:
    print(df_ind['C0-P0_price'].mean() )
for df_ind in df_ind_list:
    print(df_ind['C0-P0_welfare'].mean() )


# In[ ]:




