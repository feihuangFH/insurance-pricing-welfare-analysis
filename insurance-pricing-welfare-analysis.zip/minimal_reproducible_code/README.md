﻿# Reproducible Code Package - Insurance Pricing and Welfare Analysis

**Journal Submission Materials**  

---

## Package Contents

This package contains all code and data necessary to reproduce the main results presented in the paper.

### Directory Structure

```
reproducible_code_submission/
├── README.md
├── requirements.txt
├── shared_code/
│   └── utils.py
├── data/
│   ├── French_individual_traditional.csv
│   ├── Additional_data_individual_traditional.csv
│   └── French_data_cost_model_result/
├── french_data/
│   ├── welfare_analysis_french.py
│   ├── visualize_welfare_french.py
│   ├── visualize_competition_french.py
│   └── utils.py
├── additional_data/
│   ├── welfare_analysis_additional.py
│   ├── visualize_welfare_additional.py
│   └── utils.py
├── results/
│   ├── french_data/
│   └── additional_data/
└── shared_code/
    └── utils.py
```

---

## Quick Start

### 1. System Requirements

- **Python:** 3.8 or higher
- **RAM:** Minimum 8GB (16GB recommended)
- **Storage:** ~5GB for full results
- **OS:** Linux, macOS, or Windows

### 2. Installation

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 3. Running the Analysis

#### French Data (with competition analysis)

```bash
cd french_data

# Run welfare analysis
python welfare_analysis_french.py

# Visualize results
python visualize_welfare_french.py

# Generate competition plots
python visualize_competition_french.py
```

#### Additional Data

```bash
cd additional_data

# Run welfare analysis
python welfare_analysis_additional.py

# Visualize results
python visualize_welfare_additional.py
```


