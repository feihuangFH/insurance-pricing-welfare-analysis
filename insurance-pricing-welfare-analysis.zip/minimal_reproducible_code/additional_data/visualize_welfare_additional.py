import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
from matplotlib.patches import Rectangle
# from utils import *
import numpy as np
import seaborn as sns
import causallearn.utils.cit as cit
import causallearn.utils.KCI.KCI as kci

import plotly.graph_objects as go
from plotly import offline

import warnings
warnings.filterwarnings('ignore')

plt.rcParams.update({'font.size': 14})



#0. Read data
# result_dir = 'results_French_no_ins_as_outside_option'
result_dir = 'JRI_additional_results_NORMALIZED/additional_data_outside_option_uninsured'
flag_gini = True
flag_kci = True
price_range_min = 250
price_range_max = 325
cost_markup_range = [1.55,2.2]
cost_welfare_impact_range = [-5200,2000]
price_markup_range = [3.0,4.0]


df_summary = pd.read_csv(f'{result_dir}/welfare_result_summary.csv',index_col=0)
df_summary.set_index('model',inplace=True)
df_ind = pd.read_csv(f'{result_dir}/welfare_result_individual.csv',index_col=0)

#Temporary fix of duplication/PFM not working
# df_summary = df_summary.iloc[ list(range(32))+list(range(58,66)) ]
###


df_traditional =pd.read_csv('Additional_data_individual_traditional_NORMALIZED.csv',index_col=0)
df_ind = df_ind.merge(df_traditional,left_index=True,right_index=True)
n_consumer = len(df_ind)


models = df_summary.index
base_model = 'C0-P0'
cost_only_models = [m for m in models if 'P0' in m]
price_only_models = [m for m in models if 'C0' in m]
joint_models = [m for m in models if ( ('P0' not in m) and ('C0' not in m) )]


# 1. Compute statistics.
#Measure welfare as change from no-insurance state
df_summary['welfare_gain0'] =  df_summary['welfare0']-df_summary['welfare0_no_insurance']
df_summary['welfare_gain1'] =  df_summary['welfare1']-df_summary['welfare1_no_insurance']
df_summary['welfare_gain'] =  df_summary['welfare']-df_summary['welfare_no_insurance']
for model in models:
    df_ind[model+'_welfare_gain'] =  df_ind[model+'_welfare'] - df_ind['ce_no_insurance']
df_summary['profit_loss_pct'] = (df_summary['profit']/df_summary.loc['C0-P0','profit']-1. )*100.
df_summary['welfare_loss_pct'] = (df_summary['welfare_gain']/df_summary.loc['C0-P0','welfare_gain']-1. ) *100.

#Add accuracy data
df_oos = pd.read_csv('data/French_data_cost_model_result/cost modelling for French Claims Data/Out-of-sample Accuracy/Overall_Accuracy_Pure_Premium.csv',index_col=0)
df_oos['Model_'] = df_oos['Model'].replace({'Model.1':'C0','Model.2':'CU','Model.3':'CDP','Model.5':'CC'})
df_oos['Type_'] = df_oos['Type'].replace({'GLM':'CA-', 'XGBoost':''})
df_oos['cost_model'] = df_oos['Type_']+df_oos['Model_']
df_oos['cost_model'] = df_oos['cost_model'].replace({'CA-C0':'CA'})

for m in cost_only_models:
    df_summary.loc[m,'rmse'] = df_oos.loc[df_oos['cost_model']==m[:-3], 'avgRMSE'].values
df_summary['rmse'].fillna(method='ffill', inplace=True)

# Change of welfare from C0-P0
df_summary['welfare_change0'] = df_summary['welfare0']-df_summary.loc['C0-P0','welfare0']
df_summary['welfare_change1'] = df_summary['welfare1']-df_summary.loc['C0-P0','welfare1']
df_summary['welfare_change'] = df_summary['welfare']-df_summary.loc['C0-P0','welfare']
df_summary['profit_change'] = df_summary['profit']-df_summary.loc['C0-P0','profit']

df_summary['mean_est_mc_ratio'] = df_summary['mean_est_mc0']/df_summary['mean_est_mc1']



# Min and max for graphing
group_welfare_min = df_summary[['welfare0','welfare1']].min().min()-1000
group_welfare_max = df_summary[['welfare0','welfare1']].max().max()+1000
group_mean_price_min = df_summary[['mean_price0','mean_price1']].min().min()-50
group_mean_price_max = df_summary[['mean_price0','mean_price1']].max().max()+50
profit_min = df_summary[['profit']].min().min()-3000
profit_max = df_summary[['profit']].max().max()+3000
welfare_min = df_summary[['welfare']].min().min()-1000
welfare_max = df_summary[['welfare']].max().max()+1000

# male and female df
df_temp = df_ind[['s','C0-P0_estimated_cost','C0-P0_price']]
df_temp['cost_price_ratio'] = (df_temp['C0-P0_estimated_cost']+.01)/(df_temp['C0-P0_price']+.01)
df_temp['price_cost_ratio'] = (df_temp['C0-P0_price']+.01)/(df_temp['C0-P0_estimated_cost']+.01)
# df_male = df_temp.loc[df_ind['Gender_Male']==1]
# df_female = df_temp.loc[df_ind['Gender_Male']==0]


# Create handler.
markers = {}
colors = {}
filling = {}
#To create legends. https://stackoverflow.com/questions/45140295/how-to-create-a-legend-of-both-color-and-marker
# handles = []
# f = lambda m,c: plt.plot([],[],marker=m, color=c, ls="none")[0]
#Switched to https://stackoverflow.com/questions/47391702/how-to-make-a-colored-markers-legend-from-scratch

for m in models:
    if 'CU' in m:
        colors[m] = 'r'
    elif 'CDP' in m:
        colors[m] = 'g'
    elif 'CC' in m:
        colors[m] = 'b'
    else:
        colors[m] = 'k'

    if 'CA' in m:
        filling[m] = 'none'
    else:
        filling[m] = colors[m]

    if 'P0' in m:
        markers[m] = 'o'
    elif 'PA' in m:
        if 'PAF' in m:
            markers[m] = 'P'
        else:
            markers[m] = '^'
    elif 'POB' in m:
        markers[m] = 'v'
    elif 'PDP' in m:
        markers[m] = 's'
handles_c = []
handles_p = []
handles = []
cm_to_color = {'C0':'k','CU':'r','CDP':'g','CC':'b'}
pm_to_shape = {'P0':'o','PA':'^','POB':'v','PDP':'s','PAF':'P'}
am_to_fill = {'with CA':'none','w/o CA':'lightgray'}
for c_ in ['C0', 'CU','CDP', 'CC']:
    h_ = mlines.Line2D([], [], color=cm_to_color[c_], marker='o', linestyle='None',
                          markersize=10, label=c_)
    handles_c.append(h_)
    handles.append(h_)
for a_ in ['with CA', 'w/o CA']:
    h_ = mlines.Line2D([], [], color='lightgray', marker='*', linestyle='None',mfc=am_to_fill[a_],
                          markersize=10, label=a_)
    handles_c.append(h_)
    handles.append(h_)
for p_ in  ["P0", "PA", "POB", "PDP", "PAF"]:
    h_ = mlines.Line2D([], [], color='k', marker=pm_to_shape[p_], linestyle='None',
                          markersize=10, label=p_)
    handles_p.append(h_)
    handles.append(h_)



# Equality comparison. Gini coefficient takes time.
def calc_lorenz(arr):
    # this divides the prefix sum by the total sum
    # this ensures all the values are between 0 and 1.0
    arr = np.sort(arr)
    scaled_prefix_sum = arr.cumsum() / arr.sum()
    # this prepends the 0 value (because 0% of all people have 0% of all wealth)
    return np.insert(scaled_prefix_sum, 0, 0)

df_lc = pd.DataFrame()
for m in models:
    df_lc.loc[:,m] = calc_lorenz(df_ind[m+'_welfare_gain'])


def gini(x):
    total = 0
    for i, xi in enumerate(x[:-1], 1):
        total += np.sum(np.abs(xi - x[i:]))
    return total / (len(x)**2 * np.mean(x))


print('Computing inequality measures')
for m in models:
    df_temp = df_ind[['s','C0-P0_estimated_cost',f'{m}_price',f'{m}_welfare_gain']]
    df_temp['cost_price_ratio'] = (df_temp['C0-P0_estimated_cost']+.01)/(df_temp[f'{m}_price']+.01)
    df_temp['price_cost_ratio'] = (df_temp[f'{m}_price']+.01)/(df_temp['C0-P0_estimated_cost']+.01)
    df_male = df_temp.loc[df_ind['drv_sex1_M']==1]
    df_female = df_temp.loc[df_ind['drv_sex1_M']==0]
    df_summary.loc[m,'cost_price_ratio0'] = df_male.mean()['cost_price_ratio']
    df_summary.loc[m,'cost_price_ratio1'] = df_female.mean()['cost_price_ratio']
    df_summary.loc[m,'price_cost_ratio0'] = df_male.mean()['price_cost_ratio']
    df_summary.loc[m,'price_cost_ratio1'] = df_female.mean()['price_cost_ratio']

    df_summary.loc[m,'worst_markup5%'] = df_temp['price_cost_ratio'].quantile(.95) - 1.
    df_summary.loc[m,'worst_price5%'] = df_temp[f'{m}_price'].quantile(.95)
    df_summary.loc[m,'worst_welfare5%'] = df_temp[f'{m}_welfare_gain'].quantile(.05)

    df_summary.loc[m,'best_markup5%'] = df_temp['price_cost_ratio'].quantile(.05) - 1.
    df_summary.loc[m,'best_price5%'] = df_temp[f'{m}_price'].quantile(.05)
    df_summary.loc[m,'best_welfare5%'] = df_temp[f'{m}_welfare_gain'].quantile(.95)


    if flag_gini:
        # for m in models:
        df_summary.loc[m,'gini_markup'] = gini(df_temp['price_cost_ratio'])
        df_summary.loc[m,'gini_price'] = gini(df_temp[f'{m}_price'])
        df_summary.loc[m,'gini_welfare'] = gini(df_temp[f'{m}_welfare_gain']-df_temp[f'{m}_welfare_gain'].min())

# df_male and df_female to be C0-P0
m = models[0]
df_temp = df_ind[['s','C0-P0_estimated_cost',f'{m}_price',f'{m}_welfare_gain']]
df_temp['cost_price_ratio'] = (df_temp['C0-P0_estimated_cost']+.01)/(df_temp[f'{m}_price']+.01)
df_temp['price_cost_ratio'] = (df_temp[f'{m}_price']+.01)/(df_temp['C0-P0_estimated_cost']+.01)
df_male = df_temp.loc[df_ind['drv_sex1_M']==1]
df_female = df_temp.loc[df_ind['drv_sex1_M']==0]


# KCI test for conditional independence. This takes quite some time.
if flag_kci:
    print('Performing KCI test')
    Y_col = df_ind.columns.get_loc('drv_sex1_M')
    Z_col = [df_ind.columns.get_loc(c) for c in df_traditional.drop(columns=['constant','drv_sex1_M'])]
    data_y = df_ind.iloc[:,Y_col].values.reshape([-1,1])
    data_z = df_ind.iloc[:,Z_col].values

    # cit_CIT = cit.CIT(df_ind.values, 'kci', kernelX='Gaussian', kernelY='Gaussian',\
    #                   kernelZ='Gaussian', est_width='empirical', use_gp=False, approx=False,\
    #                   polyd=2, kwidthx=.5, kwidthy=.5, kwidthz=.5)
    # kci_p_vals = {}
    # for cm in cost_only_models:
    #     X_col = df_ind.columns.get_loc(f'{cm}_price')
    #     kci_p_vals[cm] = cit_CIT(X_col,Y_col,Z_col)
    test=kci.KCI_CInd()
    for m in models:
        print(f'model {m}')
        X_col = df_ind.columns.get_loc(f'{m}_price')
        data_x = df_ind.iloc[:,X_col].values.reshape([-1,1])

        p,stat = test.compute_pvalue(data_x,data_y,data_z)
        df_summary.loc[m, 'kci_p'] = p
        df_summary.loc[m, 'kci_stat'] = stat


# 2. Draw graphs.
# 2.0 With no regulation
#CDF of markup
ax=sns.kdeplot(df_male['price_cost_ratio']-1.,cumulative=True)
ax=sns.kdeplot(df_female['price_cost_ratio']-1., cumulative=True,color='r')
ax.legend(['male','female'])
ax.set_xlabel('Markup')
ax.set_ylabel('Cumulative Density')
ax.set_xlim([0.,10.])
fig = ax.get_figure()
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_markup_density_C0-P0.png')
plt.close(fig)
#CDF of risk
ax=sns.kdeplot(df_male['C0-P0_estimated_cost'],cumulative=True)
ax=sns.kdeplot(df_female['C0-P0_estimated_cost'], cumulative=True,color='r')
ax.legend(['male','female'])
ax.set_xlabel('Cost')
ax.set_ylabel('Cumulative Density')
ax.set_xlim([0.,2000.])
fig = ax.get_figure()
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_estimated_cost_density_C0-P0.png')
plt.close(fig)
#CDF of price
ax=sns.kdeplot(df_male['C0-P0_price'],cumulative=True)
ax=sns.kdeplot(df_female['C0-P0_price'], cumulative=True,color='r')
ax.legend(['male','female'])
ax.set_xlabel('Price')
ax.set_ylabel('Cumulative Density')
ax.set_xlim([0.,2000.])
fig = ax.get_figure()
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_price_density_C0-P0.png')
plt.close(fig)


# 2.1 Cost regulations
#2.1.1 Accuracy vs fairness, welfare
fig, ax = plt.subplots(1,figsize=(7.,4.))
for m in cost_only_models:
    ax.plot(df_summary.loc[m,'rmse'],df_summary.loc[m,'mean_est_mc_ratio']
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
# ax.legend(handles,labels)
ax.axhline(1.,linestyle='--',color='k')
ax.axvline(df_summary.loc[cost_only_models[0],'rmse'],linestyle='--',color='k')
ax.axhline(df_summary.loc[cost_only_models[0],'mean_est_mc_ratio'],linestyle='--',color='k')
ax.invert_xaxis()
ax.legend(handles=handles_c, bbox_to_anchor=(1.0, 1.0))
ax.set_xlabel('RMSE')
ax.set_ylabel('Ratio of estimated cost (male/female)')
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_RMSE_risk.pdf')
plt.close(fig)


fig, ax = plt.subplots(1,figsize=(7.,4.))
for m in cost_only_models:
    ax.plot(df_summary.loc[m,'rmse'],df_summary.loc[m,'welfare_gain']
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
# ax.legend(handles,labels)
ax.invert_xaxis()
ax.axvline(df_summary.loc[cost_only_models[0],'rmse'],linestyle='--',color='k')
ax.axhline(df_summary.loc[cost_only_models[0],'welfare_gain'],linestyle='--',color='k')
ax.legend(handles=handles_c, bbox_to_anchor=(1.0, 1.0))
ax.set_xlabel('RMSE')
ax.set_ylabel('Consumer Welfare')
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_RMSE_welfare.pdf')
plt.close(fig)


fig, ax = plt.subplots(1)
for m in cost_only_models:
    ax.plot(df_summary.loc[m,'rmse'],df_summary.loc[m,'profit']
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
# ax.legend(handles,labels)
ax.invert_xaxis()
ax.axvline(df_summary.loc[cost_only_models[0],'rmse'],linestyle='--',color='k')
ax.axhline(df_summary.loc[cost_only_models[0],'profit'],linestyle='--',color='k')
ax.legend(handles=handles_c)
ax.set_xlabel('RMSE')
ax.set_ylabel('Profit')
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_RMSE_profit.pdf')
plt.close(fig)


#2.1.2 Welfare
fig, ax = plt.subplots(1)
ax.axvline(df_summary.loc[cost_only_models[0],'welfare_gain'],linestyle='--',color='k')
ax.axhline(df_summary.loc[cost_only_models[0],'profit'],linestyle='--',color='k')
for m in cost_only_models:
    ax.plot(df_summary.loc[m,'welfare_gain'],df_summary.loc[m,'profit']
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
ax.legend(handles=handles_c)
ax.set_xlabel('Consumer welfare')
ax.set_ylabel('Insurer Profit')
fig.tight_layout()
# ax.set_ylim(444000,475000)
# ax.set_xlim(31500,33000)
fig.savefig(f'{result_dir}/graphs/Cost_welfare_profit.pdf')
plt.close(fig)


#2.1.3 Heterogeneity
##Heterogeneity across cost
fig, ax = plt.subplots(1)
x_ = np.arange(20,1500)
for cm in cost_only_models:
    poly_ = np.poly1d(np.polyfit(df_ind['C0-P0_estimated_cost'], df_ind[f'{cm}_welfare']  - df_ind['C0-P0_welfare'], 5))
    if cm=='C0-P0':
        ax.plot( x_, poly_(x_), '--' )
    else:
        ax.plot( x_, poly_(x_) )
ax.legend([cm[:-3] for cm in cost_only_models], bbox_to_anchor=(1.0, 1.0))
# ax.axhline(0.,linestyle='--',color='k')
ax.set_xlabel('Cost')
ax.set_ylabel('Welfare gain from regulation')
fig.set_size_inches(7, 4)
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_hetero_risk_welfare.pdf')
plt.close(fig)

##Heterogeneity across age
fig, ax = plt.subplots(1)
x_ = np.arange(20,65)
for cm in cost_only_models:
    poly_ = np.poly1d(np.polyfit(df_ind['drv_age1'], df_ind[f'{cm}_welfare']  - df_ind['C0-P0_welfare'], 5))
    if cm=='C0-P0':
        ax.plot( x_, poly_(x_), '--' )
    else:
        ax.plot( x_, poly_(x_) )
ax.legend([cm[:-3] for cm in cost_only_models], bbox_to_anchor=(1.0, 1.0))
# ax.axhline(0.,linestyle='--',color='k')
ax.set_xlabel('Age')
ax.set_ylabel('Welfare gain from regulation')
fig.set_size_inches(7, 4)
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_hetero_age_welfare.pdf')
plt.close(fig)



#2.1.4 Gender gap
#Price
fig, ax = plt.subplots(1)
# ax.set_xlim(group_mean_price_min, group_mean_price_max)
# ax.set_ylim(group_mean_price_min, group_mean_price_max)
ax.axvline(df_summary.loc[cost_only_models[0],'mean_price0'],linestyle='--',color='k')
ax.axhline(df_summary.loc[cost_only_models[0],'mean_price1'],linestyle='--',color='k')
ax.axline([price_range_min,price_range_min], [price_range_max, price_range_max])
for m in cost_only_models:
    ax.plot(df_summary.loc[m,'mean_price0'],df_summary.loc[m,'mean_price1']
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
ax.legend(handles=handles_c)
ax.set_xlabel('Male mean price')
ax.set_ylabel('Female mean price')
# fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_gender_price.pdf')
plt.close(fig)

#Markup
fig, ax = plt.subplots(1)
# ax.set_xlim(group_mean_price_min, group_mean_price_max)
# ax.set_ylim(group_mean_price_min, group_mean_price_max)
# ax.axline([1.95,1.95], [2.5, 2.5])
ax.axline([cost_markup_range[0],cost_markup_range[0]], [cost_markup_range[1], cost_markup_range[1]])
ax.axvline(df_summary.loc[cost_only_models[0],'price_cost_ratio0']-1.,linestyle='--',color='k')
ax.axhline(df_summary.loc[cost_only_models[0],'price_cost_ratio1']-1.,linestyle='--',color='k')
for m in cost_only_models:
    ax.plot(df_summary.loc[m,'price_cost_ratio0']-1.,df_summary.loc[m,'price_cost_ratio1']-1.
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
ax.legend(handles=handles_c)
ax.set_xlabel('Male markup')
ax.set_ylabel('Female markup')
# ax.set_xlim(1.95,2.5)
# ax.set_ylim(2.2,2.6)
# fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_price-cost_ratio_scatter.pdf')
plt.close(fig)

#Welfare
fig, ax = plt.subplots(1)
ax.axvline(df_summary.loc[cost_only_models[0],'welfare_gain0'],linestyle='--',color='k')
ax.axhline(df_summary.loc[cost_only_models[0],'welfare_gain1'],linestyle='--',color='k')
for m in cost_only_models:
    ax.plot(df_summary.loc[m,'welfare_gain0'],df_summary.loc[m,'welfare_gain1']
               ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
ax.legend(handles=handles_c)
ax.set_xlabel('Male welfare')
ax.set_ylabel('Female welfare')
# ax.set_ylim(23000,30000)
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_gender_welfare.pdf')
plt.close(fig)

#Welfare impact
ax=df_summary.loc[cost_only_models,['welfare_change0','welfare_change1']].plot(kind='bar')
ax.legend(['male welfare change','female welfare change'])
ax.axhline(0,0,1)
fig = ax.get_figure()
ax.set_ylim(cost_welfare_impact_range)
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_gender_welfare_change_bar.pdf')
plt.close(fig)

# 2.1.5 Inequality
#Spread
ax=sns.boxplot(data=pd.melt(df_ind[[cm +'_welfare_gain' for cm in cost_only_models]]),x='variable',y='value',fliersize=0.3)#,vmax=100
ax.set_xlabel('')
ax.set_ylabel('welfare')
ax.set_xticklabels([cm[:-3] for cm in cost_only_models])
fig = ax.get_figure()
fig.set_size_inches(7, 4)
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_spread_welfare.pdf')
plt.close(fig)

#Lorenz curve
ax=df_lc[cost_only_models].plot(style=['--','','','',''])
ax.legend([cm[:-3] for cm in cost_only_models])
fig = ax.get_figure()
ax.set_xlabel('Welfare')
# fig.set_size_inches(7, 6)
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Cost_welfare_lorenz.pdf')
plt.close(fig)

#Gini coeffients
if flag_gini:
    fig, ax = plt.subplots(1)
    # ax.set_xlim(group_mean_price_min, group_mean_price_max)
    # ax.set_ylim(group_mean_price_min, group_mean_price_max)
    ax.axvline(df_summary.loc[cost_only_models[0],'gini_price'],linestyle='--',color='k')
    ax.axhline(df_summary.loc[cost_only_models[0],'gini_markup'],linestyle='--',color='k')
    for m in cost_only_models:
        ax.plot(df_summary.loc[m,'gini_price'],df_summary.loc[m,'gini_markup']
                   ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
    ax.legend(handles=handles_c)
    ax.set_xlabel('Gini price')
    ax.set_ylabel('Gini markup')
    # fig.tight_layout()
    fig.savefig(f'{result_dir}/graphs/Cost_gini-price-markup.pdf')
    plt.close(fig)

    fig, ax = plt.subplots(1)
    # ax.set_xlim(group_mean_price_min, group_mean_price_max)
    # ax.set_ylim(group_mean_price_min, group_mean_price_max)
    ax.axvline(df_summary.loc[cost_only_models[0],'gini_markup'],linestyle='--',color='k')
    ax.axhline(df_summary.loc[cost_only_models[0],'gini_welfare'],linestyle='--',color='k')
    for m in cost_only_models:
        ax.plot(df_summary.loc[m,'gini_markup'],df_summary.loc[m,'gini_welfare']
                   ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
    ax.legend(handles=handles_c)
    ax.set_xlabel('Gini markup')
    ax.set_ylabel('Gini welfare')
    # fig.tight_layout()
    fig.savefig(f'{result_dir}/graphs/Cost_gini-markup-welfare.pdf')
    plt.close(fig)


# 2.2 Price regulations
# 2.2.1 Welfare
fig, ax = plt.subplots(1)
# ax.set_xlim(welfare_min, welfare_max)
# ax.set_ylim(profit_min, profit_max)
ax.axvline(df_summary.loc[price_only_models[0],'welfare_gain'],linestyle='--',color='k')
ax.axhline(df_summary.loc[price_only_models[0],'profit'],linestyle='--',color='k')
for m in price_only_models:
    ax.scatter(df_summary.loc[m,'welfare_gain'],df_summary.loc[m,'profit']
               ,marker=markers[m],c=colors[m],label=m)
ax.legend(handles=handles_p)
ax.set_xlabel('Consumer welfare')
ax.set_ylabel('Insurer Profit')
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_welfare_profit.pdf')
plt.close(fig)


# 2.2.2 Heterogeneity
# Heterogeneity across cost
fig, ax = plt.subplots(1)
x_ = np.arange(100,2000)
for pm in ['P0','PA', 'POB', 'PDP', 'PAF']:
    poly_ = np.poly1d(np.polyfit(df_ind['C0-P0_estimated_cost'], df_ind[f'C0-{pm}_welfare']  - df_ind['C0-P0_welfare'], 5))
    if pm=='P0':
        ax.plot( x_, poly_(x_),'--' )
    else:
        ax.plot( x_, poly_(x_) )
ax.legend(['P0','PA', 'POB', 'PDP', 'PAF'])
# ax.axhline(0.,linestyle='--',color='k')
ax.set_xlabel('Cost')
ax.set_ylabel('Welfare gain')
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_risk_welfare.pdf')
plt.close(fig)

# Heterogeneity across age
# np.polyfit(df_ind['drv_age1'], df_ind['C0-POB_welfare']  - df_ind['C0-P0_welfare'] , deg=2, full=True)
fig, ax = plt.subplots(1)
x_ = np.arange(20,65)
for pm in ['P0','PA', 'POB', 'PDP', 'PAF']:
    poly_ = np.poly1d(np.polyfit(df_ind['drv_age1'], df_ind[f'C0-{pm}_welfare']  - df_ind['C0-P0_welfare'], 5))
    if pm=='P0':
        ax.plot( x_, poly_(x_),'--' )
    else:
        ax.plot( x_, poly_(x_) )
ax.legend(['P0','PA', 'POB', 'PDP', 'PAF'])
# ax.axhline(0.,linestyle='--',color='k')
ax.set_xlabel('Age')
ax.set_ylabel('Welfare gain')
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_age_welfare.pdf')
plt.close(fig)


# 2.2.3 Gender gap
#Price
fig, ax = plt.subplots(1)
# ax.set_xlim(group_welfare_min, group_welfare_max)
# ax.set_ylim(group_welfare_min, group_welfare_max)
ax.axline([price_range_min, price_range_min], [price_range_max, price_range_max])
ax.axvline(df_summary.loc[price_only_models[0],'mean_price0'],linestyle='--',color='k')
ax.axhline(df_summary.loc[price_only_models[0],'mean_price1'],linestyle='--',color='k')

for m in price_only_models:
    ax.scatter(df_summary.loc[m,'mean_price0'],df_summary.loc[m,'mean_price1']
               ,marker=markers[m],c=colors[m],label=m)
ax.legend(handles=handles_p)
ax.set_xlabel('Male price')
ax.set_ylabel('Female price')
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_gender_price.pdf')
plt.close(fig)

#Markup
fig, ax = plt.subplots(1)
# ax.set_xlim(group_welfare_min, group_welfare_max)
# ax.set_ylim(group_welfare_min, group_welfare_max)

ax.axline([price_markup_range[0], price_markup_range[0]], [price_markup_range[1], price_markup_range[1]])
ax.axvline(df_summary.loc[price_only_models[0],'price_cost_ratio0']-1.,linestyle='--',color='k')
ax.axhline(df_summary.loc[price_only_models[0],'price_cost_ratio1']-1.,linestyle='--',color='k')

for m in price_only_models:
    ax.scatter(df_summary.loc[m,'price_cost_ratio0']-1.,df_summary.loc[m,'price_cost_ratio1']-1.
               ,marker=markers[m],c=colors[m],label=m)
ax.legend(handles=handles_p)
ax.set_xlabel('Male markup')
ax.set_ylabel('Female markup')
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_gender_markup.pdf')
plt.close(fig)

#Welfare impact
ax = df_summary.loc[price_only_models,['welfare_change0','welfare_change1']].plot(kind='bar')
ax.legend(['male welfare change','female welfare change'])
ax.axhline(0,0,1)
ax.set_xticklabels([pm[3:] for pm in price_only_models])
fig = ax.get_figure()
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_gender_welfare_change_bar.pdf')
plt.close(fig)

# Price Gender Welfare Change Ratio Bar plot (percentage change compared to P0)
p0_welfare0 = df_summary.loc['C0-P0', 'welfare0']
p0_welfare1 = df_summary.loc['C0-P0', 'welfare1']

# Calculate percentage changes using welfare_change0 and welfare_change1 (already differences from P0)
welfare_change_ratio0 = [df_summary.loc[m, 'welfare_change0'] / abs(p0_welfare0) * 100 
                        if p0_welfare0 != 0 else 0 for m in price_only_models]
welfare_change_ratio1 = [df_summary.loc[m, 'welfare_change1'] / abs(p0_welfare1) * 100 
                        if p0_welfare1 != 0 else 0 for m in price_only_models]

# Create DataFrame with ratio data
ratio_data = pd.DataFrame({
    'welfare_change_ratio0': welfare_change_ratio0,
    'welfare_change_ratio1': welfare_change_ratio1
}, index=price_only_models)

ax = ratio_data.plot(kind='bar')
ax.legend(['male welfare change ratio (%)','female welfare change ratio (%)'], fontsize=8)
ax.axhline(0,0,1)
ax.set_xticklabels([pm[3:] for pm in price_only_models])
fig = ax.get_figure()
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_gender_welfare_change_ratio_bar.pdf')
plt.close(fig)

# Price Welfare Profit Ratio plot (percentage change compared to P0)
fig, ax = plt.subplots(1)
p0_welfare = df_summary.loc['C0-P0', 'welfare']
p0_profit = df_summary.loc['C0-P0', 'profit']

# Calculate percentage changes using welfare_change and profit_change (already differences from P0)
welfare_ratio = [df_summary.loc[m, 'welfare_change'] / abs(p0_welfare) * 100 
                if p0_welfare != 0 else 0 for m in price_only_models]
profit_ratio = [df_summary.loc[m, 'profit_change'] / abs(p0_profit) * 100 
               if p0_profit != 0 else 0 for m in price_only_models]

ax.axvline(0, linestyle='--', color='k')
ax.axhline(0, linestyle='--', color='k')
for m in price_only_models:
    welfare_ratio_val = df_summary.loc[m, 'welfare_change'] / abs(p0_welfare) * 100 if p0_welfare != 0 else 0
    profit_ratio_val = df_summary.loc[m, 'profit_change'] / abs(p0_profit) * 100 if p0_profit != 0 else 0
    ax.scatter(welfare_ratio_val, profit_ratio_val,
               marker=markers[m], c=colors[m], label=m)
ax.legend(handles=handles_p)
ax.set_xlabel('Consumer welfare change ratio (%)')
ax.set_ylabel('Insurer Profit change ratio (%)')
# Format x-axis to show 1 decimal place
ax.ticklabel_format(style='plain', axis='x')
ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'{x:.1f}'))
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_welfare_profit_ratio.pdf')
plt.close(fig)


# 2.2.4 Inequality
#Spread
ax=sns.boxplot(data=pd.melt(df_ind[[pm +'_welfare_gain' for pm in price_only_models]]),x='variable',y='value',fliersize=0.3)#,vmax=100
ax.set_xlabel('')
ax.set_ylabel('welfare')
ax.set_xticklabels([pm[3:] for pm in price_only_models])
fig = ax.get_figure()
fig.set_size_inches(7, 4)
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_spread_welfare.pdf')
plt.close(fig)

#Lorenz curve
ax=df_lc[price_only_models].plot(style=['--','','','',''])
ax.legend([pm[3:] for pm in price_only_models])
fig = ax.get_figure()
ax.set_xlabel('Welfare')
# fig.set_size_inches(7, 6)
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Price_welfare_lorenz.pdf')
plt.close(fig)

#Gini coefficients
if flag_gini:
    fig, ax = plt.subplots(1)
    # ax.set_xlim(group_mean_price_min, group_mean_price_max)
    # ax.set_ylim(group_mean_price_min, group_mean_price_max)
    ax.axvline(df_summary.loc[price_only_models[0],'gini_markup'],linestyle='--',color='k')
    ax.axhline(df_summary.loc[price_only_models[0],'gini_welfare'],linestyle='--',color='k')
    for m in price_only_models:
        ax.plot(df_summary.loc[m,'gini_markup'],df_summary.loc[m,'gini_welfare']
                   ,marker=markers[m],mfc=filling[m],c=colors[m],label=m)
    ax.legend(handles=handles_p)
    ax.set_xlabel('Gini markup')
    ax.set_ylabel('Gini welfare')
    # fig.tight_layout()
    fig.savefig(f'{result_dir}/graphs/Price_gini-markup-welfare.pdf')
    plt.close(fig)


# 2.3 Joint regulations - Skip for single cost model case
# Since we only have one cost model (C0), we'll skip the joint heatmaps
# and create simpler comparison plots instead

# Create a simple comparison plot for the 5 price models
fig, ax = plt.subplots(1, figsize=(10, 6))
models_to_plot = ['C0-P0', 'C0-PA', 'C0-POB', 'C0-PDP', 'C0-PAF']
welfare_values = [df_summary.loc[m, 'welfare_gain'] for m in models_to_plot]
profit_values = [df_summary.loc[m, 'profit'] for m in models_to_plot]

ax.scatter(welfare_values, profit_values, s=100, c=['black', 'red', 'blue', 'green', 'orange'])
for i, model in enumerate(models_to_plot):
    ax.annotate(model, (welfare_values[i], profit_values[i]), xytext=(5, 5), textcoords='offset points')

ax.set_xlabel('Consumer Welfare')
ax.set_ylabel('Insurer Profit')
ax.set_title('Welfare vs Profit Comparison')
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Model_comparison_welfare_profit.pdf')
plt.close(fig)

# Price ratio comparison
fig, ax = plt.subplots(1, figsize=(10, 6))
price_ratios = [df_summary.loc[m, 'mean_price_ratio'] for m in models_to_plot]
model_names = [m[3:] for m in models_to_plot]  # Remove C0- prefix

bars = ax.bar(model_names, price_ratios, color=['black', 'red', 'blue', 'green', 'orange'])
ax.axhline(y=1.0, color='red', linestyle='--', label='Perfect Equality')
ax.set_ylabel('Price Ratio (Male/Female)')
ax.set_title('Gender Price Gap by Model')
ax.legend()
fig.tight_layout()
fig.savefig(f'{result_dir}/graphs/Model_comparison_price_ratio.pdf')
plt.close(fig)


df_summary.to_csv(f'{result_dir}/welfare_result_summary_updated.csv')
