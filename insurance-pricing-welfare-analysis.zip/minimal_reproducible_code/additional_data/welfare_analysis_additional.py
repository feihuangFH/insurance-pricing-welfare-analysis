'''
Extra results to generate for Jouurnal of Risk and Insurance revision.

This version includes FEATURE NORMALIZATION to ensure numerical stability
in the PA (accountability) pricing model.

Key Features:
- Continuous features (vh_value, vh_cyl, etc.) are normalized using StandardScaler
- This prevents numerical instability in PA model optimization
- All other aspects of the analysis remain identical

# Tensorflow constrained optimization requires a very specific environment.
Testing:
python==3.8
tensorflow==2.4.1

'''

import os
import pickle
import pandas as pd
import matplotlib.pyplot as plt

from utils import *


import numpy as np
from sklearn.linear_model import LinearRegression
import re
from tqdm import tqdm
from timeit import default_timer as timer

import tensorflow as tf
import tensorflow_constrained_optimization as tfco

# from tensorflow.python.ops.numpy_ops import np_config
# np_config.enable_numpy_behavior()

# Set random seeds for reproducibility
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)
tf.random.set_seed(RANDOM_SEED)
print(f"Random seeds set to {RANDOM_SEED} for reproducibility")

print(tf.__version__)

def gen_initial_guess(cost_model, price_model, s=None, risk_group = None, df_prev=None, x_init=None, df_traditional=None, mc=None, file_dir='results_additional_data'):
    regulation_model = f"{cost_model}-{price_model}" 
    
    pm_list = price_model.split('-')
    #1. Try to read the initial guess
    if x_init is not None:
        return x_init
    elif os.path.exists(f'{file_dir}/x_init_{regulation_model}.pickle'):
        print(f'Reading x_init from past trial.')
        with open(f'{file_dir}/x_init_{regulation_model}.pickle', 'rb') as f:
            x_init = pickle.load(f)
        return x_init
    
    #2. Try to use a given dataframe of individual prices
    if df_prev is None:
        use_df = False
    elif df_prev is not None:
        ## Use the previous results
        use_df = True
        if f'{regulation_model}_price' in df_prev.keys():
            price_init = df_prev[f'{regulation_model}_price']
        elif f'C0-{price_model}_price' in df_prev.keys():
            price_init = df_prev[f'C0-{price_model}_price']
        elif f'{cost_model}-P0_price' in df_prev.keys():
            price_init = df_prev[f'{cost_model}-P0_price']
        elif f'C0-P0_price' in df_prev.keys():
            price_init = df_prev[f'C0-P0_price']
        else:
            use_df = False
    if use_df:
        print('Using the previous dataframe for initial guess.')
        if 'PA' in pm_list: #Accountability constraint
            reg = LinearRegression(fit_intercept=False)
            reg.fit(df_traditional, np.log1p(price_init.values) )
            pa_init_guess = reg.coef_ * 1.
            x_init =  pa_init_guess.astype(np.float32)          
        elif 'POB' in pm_list:
            reg = LinearRegression(fit_intercept=True)
            reg.fit(mc.reshape([-1,1]), price_init)
            pob_init_guess = np.array( [ reg.intercept_, reg.coef_[0] ] ).astype(np.float32) 
            x_init =  pob_init_guess.astype(np.float32) 
        elif ('PDP' in pm_list):
            mean_diff = np.mean(price_init.loc[s==0])/np.mean(price_init.loc[s==1]) -1
            pdp_init_guess = ( price_init/ (1+ (1-s)*mean_diff) ).astype(np.float32)
            x_init = pdp_init_guess.values.astype(np.float32)
        # elif 'PFM' in pm_list:
        #     assert price_init.shape == mc.shape
        #     markup = (price_init/mc)-1.
        #     mean_diff = np.mean(markup.loc[s==0])/np.mean(markup.loc[s==1]) -1
        #     markup_init = ( markup/ (1+ (1-s)*mean_diff) ).astype(np.float32)
        #     x_init = (price_init * (1.+markup_init)).values.astype(np.float32)
        elif 'PAF' in pm_list:
            paf_init_guess = pd.Series( np.zeros(len(price_init)), index = price_init.index )
            for g in risk_group.unique():
                mean_diff = np.mean(price_init.loc[((s==0) & (risk_group==g))])/np.mean(price_init.loc[((s==1) & (risk_group==g))]) -1
                paf_init_guess.loc[( (risk_group==g))] = ( price_init.loc[((risk_group==g))]/ (1+ (1-s)*mean_diff) ).astype(np.float32)
            x_init = paf_init_guess.values.astype(np.float32)
            
        else:
            x_init = price_init.values.astype(np.float32)
        return x_init
                                                                                                                                                                                                                       
    #3. Crete initial guess from scratch.
    print('Creating the initial guess from scratch')
    if 'PA' in pm_list: #Accountability constraint
        print('Initial guess for PA by linear regression.')
        reg = LinearRegression(fit_intercept=False)
        reg.fit(df_traditional, np.log1p(mc) )
        pa_init_guess = reg.coef_ * 1.5
        x_init =  pa_init_guess.astype(np.float32)                                                                 
    elif 'POB' in pm_list:
        x_init =  np.array([0,1.5]).astype(np.float32)                 
    elif 'PDP' in pm_list:
        mean_mc_diff = np.mean(mc[s==0])/np.mean(mc[s==1]) -1
        pdp_init_guess = ( mc/ (1+ (1-s)*mean_mc_diff) *1.5 ).astype(np.float32)
        x_init = pdp_init_guess.values.astype(np.float32)
    elif 'PFM' in pm_list:
        print('Initial guess for PFM by constant markup.')
        x_init = (mc*1.5).astype(np.float32)
    else:
        x_init = (mc*1.5).astype(np.float32)
    return x_init

        
    

def gen_model(df, df_traditional, cost_model, price_model, s=None, df_prev=None, source='additional_data', init_folder = None, n_sample=3000, d=0):
    ## Cost model setting
    # t = 'telem1' if flag_telem else 'telem0'
    if source=='SBV':
        t = 'telem0' if 'CA' in cost_model else 'telem1'
    elif source=='French':
        t = 'telem0'
    elif source=='additional_data':
        t = 'telem0'
    ml_model = 'glm' if 'CA' in cost_model else 'xgb'
    if 'CU' in cost_model:
        m = 'M2'
    elif 'CDP' in cost_model:
        m = 'M3'
    elif 'CC' in cost_model:
        m = 'M5'
    else:
        m = 'M1'
    firm_model = f"{m}_{t}_{ml_model}"

    ### Construct a product and firm information.
    loss_sample_firm = sample_accidents(df[f'alpha_{firm_model}'],df[f'beta_{firm_model}'],df[f'lambda_{firm_model}'],n_sample)
    est_mc = loss_to_expected_claim(d, loss_sample_firm).astype(np.float32)
    risk_group = (est_mc<=np.quantile(est_mc,.25)).astype(int)+(est_mc<=np.quantile(est_mc,.5)).astype(int)+(est_mc<=np.quantile(est_mc,.75)).astype(int)
    risk_group = pd.Series(risk_group, index=s.index)

    # Define the regulation model
    regulation_model = f"{cost_model}-{price_model}" 

    ## Price model setting
    const_list = []
    pm = price_model.split('-')
    pdp_p = None
    penalty = 0.
    fc_=[a_ for a_ in pm if a_.startswith('PDP_')]
    if 'PA' in pm: #Accountability constraint
        const_list.append('PA')
    elif 'POB' in pm: #Optimization ban
        const_list.append('POB')
    else: #Free individualized pricing with/without fairness constraint
        if 'PDP' in pm: #DP constraint
            const_list.append('PDP') 
            penalty = 1e3
        elif len(fc_)==1: #DP-p constraint
            const_list.append('PDP_p')            
            pdp_p = fc_[0].split('_')[1]/100
        elif 'PFM' in pm: #DP constraint on markup
            const_list.append('PFM') 
            penalty = 1e5
        elif 'PAF' in pm:
            const_list.append('PAF')
            penalty = 1e3
        
    '''
    if 'POB' in pm or 'PA' in pm:
        if df_prev is None:
            df_prev = individual_result_df
    else:
        if df_prev is None:
            df_prev = individual_result_df
        elif (len(df_prev)!=n_consumer):
            df_prev = individual_result_df
    '''
    if df_prev is not None:
        if (len(df_prev)!=n_consumer):
            df_prev = None
    if init_folder is None:
        init_folder = 'results_'+source
    x_init = gen_initial_guess(cost_model, price_model, s, risk_group=risk_group,df_prev=df_prev, x_init=None, df_traditional=df_traditional, mc=est_mc, file_dir = init_folder)

    print('x_init:',x_init)
    
    assert isinstance(x_init, np.ndarray)
    assert x_init.dtype==np.float32
    return loss_sample_firm, est_mc, risk_group, regulation_model, const_list, x_init, pdp_p, penalty

        
    
class PriceOptimizationProblem(tfco.ConstrainedMinimizationProblem):
    def __init__(self,x_init ,d ,u_intercept,u_price_coeff,risk_gamma,outside_value,logit_sigma,loss_sample_consumer, loss_sample_firm,
                 s=None, risk_group=None,const_list=[],consumer_X=None,d_others=None,p_others=None,pdp_p=None,penalty=0.):

        #tf.Variable to be optimized. Either represents price directly or coefficients on relativities.
        self.x = tf.Variable(x_init.astype(np.float32) ) 
        assert len( self.x.shape )==1

        #Deductible of the product
        self.d = d
        
        #Consumer characteristics
        self.u_intercept = tf.constant(u_intercept) 
        self.u_price_coeff = tf.constant(u_price_coeff)
        self.risk_gamma = tf.constant(risk_gamma)
        self.outside_value = tf.constant(outside_value)
        self.n_consumer = len(u_intercept)
        self.logit_sigma = logit_sigma

        #Samples drawn to compute expectation.
        self.loss_sample_consumer = tf.constant(loss_sample_consumer) 
        self.loss_sample_firm = tf.constant(loss_sample_firm)  
        self.total_oop_sample_list = [tf.constant( loss_to_total_oop(d, loss_sample_consumer).astype(np.float32)) ]
        self.cost_estimate = tf.constant( loss_to_expected_claim(d, loss_sample_firm).astype(np.float32) )
        self.cost_true = tf.constant( loss_to_expected_claim(d, loss_sample_consumer).astype(np.float32) )
        self.n_sample = loss_sample_consumer.shape[0]
        
        #Competitors
        self.p_others = p_others
        self.d_others = d_others
        if d_others is None:
            self.n_other_prod = 0
        else:
            if isinstance(d_others, int): 
                self.n_other_prod = 1
            else:
                self.n_other_prod = len(d_others)                                       
            self.total_oop_sample_list.append( loss_to_total_oop(d_others[j], loss_sample_consumer).astype(np.float32) ) 

        #Constraints
        self.const_list = const_list
        self.s = s
        self.risk_group = risk_group
        if risk_group is not None:
            self.n_risk_group = len( risk_group.unique() )
        self.pdp_p = pdp_p
        if 'PA' in self.const_list:
            self.consumer_X = consumer_X
        '''
        if 'PDP' in self.const_list:            
            self.num_constraints = 2
        elif 'PDP_p' in self.const_list:
            self.num_constraints = 2
        else:
            self.num_constraints = 0
        '''
        self.penalty = penalty

    
    def loss_to_value_j_tf(self, p, j=None, d=None):
        h_ij = self.loss_to_h(p,j,d)
        v_ij = tf.reduce_mean(h_ij,axis=0) - (self.risk_gamma/2) * tf.reduce_mean(h_ij**2,axis=0)            
        return v_ij
    
    # def loss_to_h(self,p,j=None,d=None):
    #     if d is None:
    #         assert j is not None
    #         total_oop_sample = self.total_oop_sample_list[j]
    #     else:
    #         assert d is not None
    #         loss_sample_consumer = self.loss_sample_consumer.numpy()
    #         total_oop_sample = tf.constant( loss_to_total_oop(d, loss_sample_consumer).astype(np.float32)) 
    #     a = tf.repeat(self.u_intercept,self.n_sample).reshape([-1,self.n_sample]).transpose() # Repeat across samples
    #     b = tf.repeat(self.u_price_coeff,self.n_sample).reshape([-1,self.n_sample]).transpose() # Repeat across samples
    #     h_ij = a - b*p  -total_oop_sample
    #     return h_ij
    def loss_to_h(self, p, j=None, d=None):
        # TF 2.4.1 version
        if d is None:
            assert j is not None
            total_oop_sample = self.total_oop_sample_list[j]
        else:
            assert d is not None
            loss_sample_consumer = self.loss_sample_consumer.numpy()
            total_oop_sample = tf.constant(loss_to_total_oop(d, loss_sample_consumer).astype(np.float32))
        a = tf.transpose(tf.reshape(tf.repeat(self.u_intercept, self.n_sample), [-1, self.n_sample]))
        b = tf.transpose(tf.reshape(tf.repeat(self.u_price_coeff, self.n_sample), [-1, self.n_sample]))
        h_ij = a - b * p - total_oop_sample
        return h_ij

    def find_ce(self, p,j=None,outside_option=False,d=None):
        '''
        Find the CE by solving h - risk_gamma/2*h^2 = v_ij where v_ij is the value of the product (computed as E[h_ij]-risk_gamma/2 E[h_i^2])
        The value h-risk_gamma/2 h^2 is increasing in h when h<1/risk_gamma.
        '''
        v_product = self.outside_value if outside_option else  self.loss_to_value_j_tf(p,j,d)     
        assert tf.reduce_all(1- 2*self.risk_gamma*v_product>0)
        h_ce = 1-tf.sqrt( 1- 2*self.risk_gamma*v_product )/self.risk_gamma
        return h_ce
    # @tf.function
    # def choice_prob_tf(self, p):
    #     v = self.loss_to_value_j_tf(p, 0)
    #     v_list = [v.reshape([-1,1])]
    #     if self.d_others is not None:
    #         for j in range(1,1+self.n_other_prod):
    #             v_other = self.loss_to_value_j_tf(self.p_others[:,j], j)
    #             v_list.append(v_other.reshape([-1,1]))
    #     v_all = tf.concat(v_list,axis=1)
    #     # assert tf.reduce_all(tf.math.is_finite(v_all)  )

    #     num = tf.exp(v_all/self.logit_sigma) 
    #     denom = (tf.reduce_sum(tf.exp(v_all/self.logit_sigma),axis=1).reshape([n_consumer,1]) + tf.exp(self.outside_value.reshape([n_consumer,1])/self.logit_sigma) ) 
    #     prob = tf.math.divide_no_nan(num, denom+1e-25 ) 

    #     # assert not tf.reduce_any(tf.math.is_nan(prob))
        

    #     return prob

    @tf.function
    def choice_prob_tf(self, p):
        # TF 2.4.1 version
        v = self.loss_to_value_j_tf(p, 0)
        v_list = [tf.reshape(v, [-1, 1])]
        if self.d_others is not None:
            for j in range(1, 1 + self.n_other_prod):
                v_other = self.loss_to_value_j_tf(self.p_others[:, j], j)
                v_list.append(tf.reshape(v_other, [-1, 1]))
        v_all = tf.concat(v_list, axis=1)
        
        num = tf.exp(v_all / self.logit_sigma)

        # 2025/04/28: The outside  value in the denominator should be also exponentiated.

        # denom = (tf.reshape(tf.reduce_sum(tf.exp(v_all / self.logit_sigma), axis=1), [self.n_consumer, 1])
        #         + tf.reshape(self.outside_value, [self.n_consumer, 1]) / self.logit_sigma)
        denom = (tf.reshape(tf.reduce_sum(tf.exp(v_all / self.logit_sigma), axis=1), [self.n_consumer, 1])
                + tf.exp( tf.reshape(self.outside_value, [self.n_consumer, 1]) / self.logit_sigma) )
        prob = tf.math.divide_no_nan(num, denom + 1e-25)
        return prob


    @property
    def num_constraints(self):
        n_const = 0
        if 'PDP' in self.const_list:
            n_const = 2
        elif 'PDP_p' in self.const_list:
            n_const = 2
        elif 'PFM' in self.const_list:
            n_const = 2
        elif 'PAF' in self.const_list:
            n_const = self.n_risk_group*2
            
        return n_const

    def gen_price(self):
        if 'PA' in self.const_list:
            #Price needs to be multiplication.
            assert self.x.shape[0]==self.consumer_X.shape[1]
            p = tf.reduce_prod(tf.exp( self.consumer_X*self.x ),axis=1)
        elif 'POB' in self.const_list:
            #Price needs to be associated to cost
            assert self.x.shape[0]==2
            p = self.x[0] + self.x[1]*self.cost_estimate
        else:
            assert self.x.shape[0]==self.n_consumer
            p = self.x
        assert p.shape==(self.n_consumer,), print(p.shape)
        return p

    @tf.function
    def objective(self):
        p = self.gen_price()
        cp = self.choice_prob_tf(p)
        demand = cp[:,0]
        prof_i = demand*(p-self.cost_estimate)
        prof = tf.reduce_sum(prof_i)
        if 'PDP' in self.const_list:
            mean_price_gap = tf.square( tf.reduce_mean(tf.boolean_mask( p+.01, self.s==0) ) - tf.reduce_mean(tf.boolean_mask( p+.01, self.s==1) ) )
            obj = prof - self.penalty*mean_price_gap
        elif 'PFM' in self.const_list:
            markup = (p / self.cost_estimate) - 1.
            mean_markup_gap = tf.square( tf.reduce_mean(tf.boolean_mask( markup+.01, self.s==0) ) - tf.reduce_mean(tf.boolean_mask( markup+.01, self.s==1) ) )
            obj = prof - self.penalty*mean_markup_gap
        elif 'PAF' in self.const_list:
            gap = 0.
            for g in self.risk_group.unique():
                gap = gap + tf.square( tf.reduce_mean(tf.boolean_mask( p+.01, ((self.risk_group==g)&(self.s==0))) ) - tf.reduce_mean(tf.boolean_mask( p+.01, ((self.risk_group==g)&(self.s==1))) ) )
            obj = prof - self.penalty*gap
        else:
            obj = prof
        return -obj
    
    def profit(self):
        p = self.gen_price()
        cp = self.choice_prob_tf(p)
        demand = cp[:,0]
        prof_i = demand*(p-self.cost_true)
        prof = tf.reduce_sum(prof_i)
        return -prof
    
    def gen_const(self):
        multiplier = 1e12
        const = []
        p = self.gen_price()
        mean_price_gap = tf.reduce_mean(tf.boolean_mask( p+.01, self.s==0) )/tf.reduce_mean(tf.boolean_mask( p+.01, self.s==1) ) - 1.
        mean_markup_gap = self.compute_mean_markup_ratio() - 1.
        if 'PDP' in self.const_list:
            const.append(mean_price_gap* multiplier)
            const.append(-mean_price_gap* multiplier)
            '''
            #mean_price_gap = tf.norm( tf.reduce_mean(tf.boolean_mask( p+.01, self.s==0) ) - tf.reduce_mean(tf.boolean_mask( p+.01, self.s==1) ) , ord=2)
            mean_price_gap = tf.square( tf.reduce_mean(tf.boolean_mask( p+.01, self.s==0) ) - tf.reduce_mean(tf.boolean_mask( p+.01, self.s==1) ))
            const.append(mean_price_gap-0.)
            const.append(0.-mean_price_gap)
            '''
        elif 'PDP_p' in self.const_list:            
            const.append( (mean_price_gap-self.pdp_p)* multiplier )
            const.append( (self.pdp_p-mean_price_gap)* multiplier )
        elif 'PFM' in self.const_list:
            const.append(mean_markup_gap* multiplier)
            const.append(-mean_markup_gap* multiplier)
        elif 'PAF' in self.const_list:
            for g in self.risk_group.unique():
                mean_price_gap = tf.reduce_mean(tf.boolean_mask( p+.01, ((self.risk_group==g)&(self.s==0))) )/tf.reduce_mean(tf.boolean_mask( p+.01, ((self.risk_group==g)&(self.s==1))) ) - 1.
                const.append(mean_price_gap* multiplier)
                const.append(-mean_price_gap* multiplier)
                
            
        return tf.stack(const)
        

    def proxy_constraints(self):
        return self.gen_const()

    def constraints(self):
        return self.gen_const()

    def compute_mean_price_ratio(self):
        p = self.gen_price()
        mean_price_ratio = tf.reduce_mean(tf.boolean_mask( p+.01, self.s==0) )/tf.reduce_mean(tf.boolean_mask( p+.01, self.s==1) )
        return mean_price_ratio
    
    def compute_mean_markup_ratio(self):
        p = self.gen_price()
        markup = (p / self.cost_estimate) - 1.
        mean_markup_ratio = tf.reduce_mean(tf.boolean_mask( markup+.00001, self.s==0) )/tf.reduce_mean(tf.boolean_mask( markup+.00001, self.s==1) )
        return mean_markup_ratio
    
    def sum_mean_price_ratio_groups(self):
        p = self.gen_price()
        temp = 0.
        for g in self.risk_group.unique():
            mean_price_gap = tf.reduce_mean(tf.boolean_mask( p+.01, ((risk_group==g)&(s==0))) )/tf.reduce_mean(tf.boolean_mask( p+.01, ((risk_group==g)&(s==1))) ) 
            temp = temp + mean_price_gap
        return temp

            
    
# Read data
##Main data
# raw_data_dir = 'code/cost modelling for French Claims Data/Data for Modelling'
# cost_data_dir = 'code/cost modelling for French Claims Data'
# source = 'French'

##Additional data for JRI revision
additional_cost_model_data_dir = 'data/French_data_cost_model_result/cost modelling for French Claims Data/Code Scripts in R/Additional Data'

def main(oo_option='mc_times_markup', oo_markup=1.5):
    """Main function to run JRI analysis for a specific outside option"""
    print(f"Starting JRI analysis: {oo_option}, markup={oo_markup}")
    
    # Save results in separate directory to distinguish from unnormalized version
    if oo_option == 'uninsured':
        result_dir = f'JRI_additional_results/additional_data_outside_option_uninsured'
    else:
        result_dir = f'JRI_additional_results/additional_data_outside_option{oo_markup}'
    
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)
        os.makedirs(result_dir+'/graphs')

    # Read the "additional" data
    print("Loading data files...")
    df_poisson = pd.read_csv(f'{additional_cost_model_data_dir}/pg17_XGB_YfM1_poisson.csv',index_col=0)
    df_gamma = pd.read_csv(f'{additional_cost_model_data_dir}/pg17_XGB_YsM1_gamma.csv',index_col=0)
    print(f"Data loaded - Poisson: {df_poisson.shape}, Gamma: {df_gamma.shape}")

    print("Processing data...")
    df = df_poisson.copy()
    # df[f'lambda_M{1}_telem{0}_xgb'] = df_poisson['lambda (predicted/annual_exposure)']#Duration is already adjusted to annual level
    df[f'alpha_M{1}_telem{0}_xgb'] = df_gamma['mean']
    df[f'beta_M{1}_telem{0}_xgb'] = 1. #for now.
    df = df.dropna()
    df = df.iloc[:2000]
    print(f"Data processed - Final shape: {df.shape}")
    
    # matching the name to the previousn version
    df['s'] = (df['drv_sex1']=='F').astype(int)
    df['lambda_M1_telem0_xgb'] = df['lambda (predicted/annual_exposure)']
    df['age'] = df['drv_age1']
    print(f"Gender distribution: {df['s'].value_counts().to_dict()}")
        
    # df = read_cost_results(raw_data_dir,cost_data_dir, source=source)
    # df = df.iloc[:2000]
    
    df_traditional = df
    # df_traditional = df[TRADITIONAL_VARS]
    # df_traditional=pd.get_dummies(df_traditional, columns=CATEGORICAL_VARS, drop_first=True)
        # df_traditional['constant'] = 1.
    # df_traditional.to_csv('individual_traditional.csv')
    
    # df_prev = pd.read_csv('welfare_result_individual_0623.csv', index_col=0)
    
    
    # ============================================================================
    # FEATURE NORMALIZATION (added to fix PA price issue)
    # ============================================================================
    # Normalize continuous features ONLY for PA model to prevent numerical instability
    # Other models (P0, POB, PDP, PAF) will use unnormalized features
    # See PA_PRICE_ISSUE_REPORT.md for detailed explanation
    
    from sklearn.preprocessing import StandardScaler
    
    # Define continuous features that need normalization
    continuous_features = ['drv_age1', 'vh_age', 'vh_cyl', 'vh_din', 
                           'vh_speed', 'vh_value', 'pol_bonus', 
                           'drv_age_lic1', 'pol_duration', 'pol_sit_duration']
    
    # Create normalized version for PA model ONLY
    df_normalized = df.copy()
    scaler = StandardScaler()
    df_normalized[continuous_features] = scaler.fit_transform(df[continuous_features])
    
    print(f"✅ Feature normalization will be applied ONLY to PA model")
    print(f"   (P0, POB, PDP, PAF will use unnormalized features)")
    print(f"   Normalizing {len(continuous_features)} continuous features for PA")
    
    # ============================================================================
    
    # Create traditional features from UNNORMALIZED data (for P0, POB, PDP, PAF)
    df_traditional = df[ADDITIONAL_DATA_X_VARS]
    df_traditional=pd.get_dummies(df_traditional, columns=ADDITIONAL_DATA_CATEGORICAL_VARS, drop_first=True)
    df_traditional['constant'] = 1.
    df_traditional.to_csv('Additional_data_individual_traditional.csv')
    
    # Create normalized traditional features (for PA only)
    df_traditional_normalized = df_normalized[ADDITIONAL_DATA_X_VARS]
    df_traditional_normalized = pd.get_dummies(df_traditional_normalized, columns=ADDITIONAL_DATA_CATEGORICAL_VARS, drop_first=True)
    df_traditional_normalized['constant'] = 1.
    df_traditional_normalized.to_csv('Additional_data_individual_traditional.csv')
    
        
    # Construct consumers
    n_consumer = len(df)
    n_sample = 3000
    logit_sigma = 39.213
    consumer_model = 'M1_telem0_xgb'#'M1_telem1_glm'
    df, loss_sample_consumer = construct_consumers(df, consumer_model, n_sample, source='additional_data')
    
    # 07/19 Try uninsured as outside option
    # df = construct_outside_option(df,loss_sample_consumer,option='uninsured', markup=None,deductible=None ,flag_inertia=True, source='French')
    
    # 09/20 markup=1.5,deductible=0
    
    # 09/25 Same but regulation reflexts to outside option price
    # df = construct_outside_option(df,loss_sample_consumer,option='mc_times_markup', markup=1.5,deductible=0 ,flag_inertia=True, source='French')
    
    # 04/25/2025 The price is sometime negative with markup=2.25. Trying uninsured as outside option.
    print(f"Constructing outside option: {oo_option}, markup={oo_markup}")
    if oo_option == 'uninsured':
        df = construct_outside_option(df,loss_sample_consumer,option='uninsured', markup=None,deductible=None ,flag_inertia=True, source='additional_data')
    else:
        df = construct_outside_option(df,loss_sample_consumer,option='mc_times_markup', markup=oo_markup, deductible=0 ,flag_inertia=True, source='additional_data')
    print("Outside option construction completed")
    
    
    
    # Convert to tf.Tensor
    loss_sample_consumer =  loss_sample_consumer.astype(np.float32) 
    u_intercept = tf.constant(df['utility_intercept'].values.astype(np.float32) )
    u_price_coeff = tf.constant(df['utility_price_coef'].values.astype(np.float32) ) 
    risk_gamma = tf.constant(df['risk_gamma'].values.astype(np.float32) )
    outside_value = tf.constant(df['value_outside'].values.astype(np.float32) )
    
    # Other environment
    d = 0#300
    p_others = None
    d_others = None
    # flag_telem = True 
    # consumer_X will be set per model (normalized for PA, unnormalized for others)
    consumer_X_unnorm = tf.constant(df_traditional.values.astype(np.float32) )
    consumer_X_norm = tf.constant(df_traditional_normalized.values.astype(np.float32) )
    s = df['s']
    cost_models = ['C0']
    # cost_models = ['C0','CU','CDP','CC','CA','CA-CU','CA-CDP','CA-CC']
    
    # 07/19 Try uninsured as outside option
    # price_models = ['P0','PA','POB','PDP']
    price_models = ['P0','PA','POB','PDP','PAF']
    # price_models = ['P0']  # Commented out to run all models
    
    # Nuisance parameter
    n_iter = 3000  # Reduced for faster execution
    lr_schedule_cvx = tf.optimizers.schedules.ExponentialDecay(
        initial_learning_rate=.3,
        decay_steps=200,
        decay_rate=.99)
    ## PA constraint requires lower learning rate as the problem is severely non-convex.
    lr_schedule_ncvx = tf.optimizers.schedules.ExponentialDecay(
        initial_learning_rate=1e-3,#5*1e-5, #1e-2 is too high.
        decay_steps=200,
        decay_rate=.99)#0.99)
    ## PDP/PAF learning rate - higher than PA since they are more well-behaved
    lr_schedule_pdp_paf = tf.optimizers.schedules.ExponentialDecay(
        initial_learning_rate=0.1,  # Higher than PA (0.001) but lower than P0 (0.3)
        decay_steps=200,
        decay_rate=.99)
    
    
    
    # 09/27/2023: Running for outside option3
    # Run all the models.
    individual_result_df = pd.DataFrame(index=df.index)
    individual_result_df['s'] = s
    individual_result_df['eta_consumer'] = df['eta_consumer']
    result_df = pd.DataFrame()
    fig_opt, axes_opt = plt.subplots(1,1,figsize=(8,6))
    # fig_opt_ce, axes_opt_ce = plt.subplots(len(cost_models),len(price_models))
    start = timer()
    
    update_consumers = True
    
    
    
    regulation_models = []
    for ci, cost_model in enumerate(cost_models):
        for pi, price_model in enumerate(price_models):
        # for pi, price_model in enumerate([price_models[1]]):
            # Use normalized features for PA model, unnormalized for all others
            df_trad_for_model = df_traditional_normalized if 'PA' in price_model else df_traditional
            
            # loss_sample_firm, est_mc, risk_group, regulation_model, const_list, x_init, pdp_p, penalty = gen_model(cost_model, price_model, s, df_prev = individual_result_df, source='additional_data', init_folder=None)
            loss_sample_firm, est_mc, risk_group, regulation_model, const_list, x_init, pdp_p, penalty = gen_model(df, df_trad_for_model, cost_model, price_model, s, df_prev = None, source='additional_data', init_folder=None)
            regulation_models.append(regulation_model)
            individual_result_df[regulation_model+'_estimated_cost'] = est_mc
            individual_result_df[regulation_model+'_risk_group'] =  risk_group
    
            if update_consumers:
                ## Update the outside options for each regulation.
                df_reg = df.copy()
                df_reg['mc_reg'] = est_mc
                #NOTE: The outside option construction assumes deductible=0 for now.
                if oo_option == 'uninsured':
                    df_reg = construct_outside_option(df_reg,loss_sample_consumer,option='uninsured', markup=None,deductible=None ,flag_inertia=True, source='additional_data')
                else:
                    df_reg = construct_outside_option(df_reg,loss_sample_consumer,option='regmc_times_markup', markup=oo_markup,deductible=0 ,flag_inertia=True, source='additional_data')
                outside_value = tf.constant(df_reg['value_outside'].values.astype(np.float32) )
    
            
    
            # Define optmization problem
            pm = price_model.split('-')
            # FIXED: Use model-specific learning rates
            # PA needs very slow LR (non-convex), PDP/PAF need medium LR, P0/POB need fast LR
            if 'PA' in const_list and 'PAF' not in const_list:
                lr = lr_schedule_ncvx  # Slow for PA (0.001)
            elif 'PDP' in const_list or 'PAF' in const_list:
                lr = lr_schedule_pdp_paf  # Medium for PDP/PAF (0.1)
            else:
                lr = lr_schedule_cvx  # Fast for P0/POB (0.3)
            
            # Use normalized consumer_X for PA model, unnormalized for all others
            consumer_X_for_model = consumer_X_norm if 'PA' in price_model else consumer_X_unnorm
            
            problem = PriceOptimizationProblem(x_init ,d ,u_intercept,u_price_coeff,risk_gamma,outside_value,logit_sigma,loss_sample_consumer, loss_sample_firm,
                             s=s, risk_group=risk_group, const_list=const_list,consumer_X=consumer_X_for_model,d_others=d_others,p_others=p_others,pdp_p=pdp_p,penalty=penalty)         
    
            '''
            '''
            # optimizer = tfco.ProxyLagrangianOptimizerV2(optimizer=tf.optimizers.Adam(learning_rate=lr),num_constraints=problem.num_constraints )
            ## optimizer = tfco.LagrangianOptimizerV2(optimizer=tf.optimizers.Adam(learning_rate=lr),num_constraints=problem.num_constraints )
            # 10/14/2024: TFCO library does not work with recent TensorFlow2 versions due to the "tape" requirement.
            # ValueError: `tape` is required when a `Tensor` loss is passed. Received: loss=<__main__.PriceOptimizationProblem object at 0x13d711950>, tape=None.
            # Since we have penalty term in the objective anyway, we can simply use the usual optimizer without constraints.
    
            # unconstrained_obj_with_penalty = problem.objective # This would work too.
            optimizer = tf.optimizers.Adam(learning_rate=lr) # Using the standard optimizer isntead of TFCO.
            
    
    
            #Optimization
            print(f'---Optimize price under {regulation_model}---')
            objective_trj = []
            const_trj = []
            for epoch in tqdm(range(n_iter)):
                # if epoch % 1 == 0:
                #     print(f'step = {i}')
                #     print(f'profit = {-problem.objective()}')
    
                '''
                10/15/2024: Adding the GradientTape() to be compatible with recent TF2 versions.
                '''
                # optimizer.minimize(problem, var_list=[problem.x]) # This does not work with recent TF2 versions.
                with tf.GradientTape() as tp:           
                    gradients = tp.gradient(problem.objective(), [problem.x])
                    optimizer.apply_gradients(zip(gradients, [problem.x]))            
                
                #10/14/2024: This would work too.
                # optimizer.minimize(unconstrained_obj_with_penalty, var_list=[problem.x])
                
                objective_trj.append(-problem.objective().numpy())
                const_trj.append(problem.compute_mean_price_ratio().numpy()-1.)
                
                if epoch>20:
                    gain_obj =  (np.max(objective_trj[-20:])- np.min(objective_trj[-20:]) )/np.abs(np.min(objective_trj[-20:])  )
                    gain_const = np.abs(np.max(const_trj[-20:]) -np.min(const_trj[-20:]) ) 
                    if gain_obj<1e-5 and gain_const<1e-5:
                        
                        break
                
                
            # axes_opt[ci,pi].plot(range(len(objective_trj)),objective_trj)
            # axes_opt[ci,pi].set_title(price_model)
            # axes_opt[ci,pi].set_ylabel(cost_model)
            # ax2 = axes_opt[ci,pi].twinx()  # instantiate a second axes that shares the same x-axis
    
            # Enhanced plotting code with labels and legends for all 5 models (same as French script)
            axes_opt.plot(range(len(objective_trj)), objective_trj, label=f'{price_model}', linewidth=2)
            axes_opt.set_xlabel('Iteration', fontsize=12)
            axes_opt.set_ylabel('Profit', fontsize=12)
            axes_opt.grid(True, alpha=0.3)
            
            # Add legend for profit curves (only once, after all models are plotted)
            # Since we have nested loops (cost_models × price_models), we need to check if this is the last price_model in the last cost_model
            if ci == len(cost_models) - 1 and pi == len(price_models) - 1:  # Last cost model AND last price model
                axes_opt.legend(loc='lower right', fontsize=10, title='Pricing Models')
                axes_opt.set_title('Optimization History - All Models', fontsize=14, fontweight='bold')
            
            fig_opt.tight_layout()
                    
    
                    
            #Record results
            with open(f'{result_dir}/x_init_{regulation_model}.pickle','wb') as f:
                pickle.dump( problem.x.numpy() , f )
            result_dict = {}
            price = problem.gen_price().numpy().flatten()
            coverage = problem.choice_prob_tf(problem.gen_price()).numpy().flatten()
    
            individual_result_df[regulation_model+'_price'] = price
            individual_result_df[regulation_model+'_coverage'] = coverage
            
            result_dict['model'] = regulation_model
            result_dict['mean_price_ratio'] = problem.compute_mean_price_ratio().numpy()
            result_dict['profit'] = - problem.profit().numpy()
            result_dict['coverage0'] = coverage[problem.s==0].mean()
            result_dict['coverage1'] = coverage[problem.s==1].mean()
            result_dict['mean_price0'] = price[problem.s==0].mean()
            result_dict['mean_price1'] = price[problem.s==1].mean()
            result_dict['mean_est_mc0'] = est_mc[problem.s==0].mean()
            result_dict['mean_est_mc1'] = est_mc[problem.s==1].mean()
    
    
            
            # Compute welfare
            ## Compute CE of the product
            if d==0:
                ce_purchase = problem.loss_to_h(problem.gen_price(),0)[0].numpy()
            else:
                ce_purchase = problem.find_ce(problem.gen_price(), 0).numpy()
            ## Compute CE of the outside option
            if 'ce_outside' in individual_result_df.keys():
                ce_outside = individual_result_df['ce_outside'].values.flatten()
            else:
                ce_outside = problem.find_ce(None,None,True).numpy()
                individual_result_df['ce_outside'] = ce_outside
            ## Compute CE of the no-insurance state
            if 'ce_no_insurance' not in df.keys():
                ce_no_insurance = problem.find_ce(0,None,False,np.inf).numpy()
                individual_result_df['ce_no_insurance'] = ce_no_insurance
    
            ## Record welfare result
            welfare = coverage*ce_purchase + (1-coverage)*ce_outside
            individual_result_df[regulation_model+'_welfare'] = welfare
            result_dict['welfare'] = welfare.mean()
            result_dict['welfare0'] = welfare[problem.s==0].mean()
            result_dict['welfare1'] = welfare[problem.s==1].mean()
            result_dict['welfare_no_insurance'] = ce_no_insurance.mean()
            result_dict['welfare0_no_insurance'] = ce_no_insurance[problem.s==0].mean()
            result_dict['welfare1_no_insurance'] = ce_no_insurance[problem.s==1].mean()
                
        
            # Add the result to the summary dataframe.
            result_df =pd.concat([result_df,pd.DataFrame(result_dict,index=[0])],axis=0,ignore_index=True)
        
            end = timer()
            print('------------------------')
            print('Total time: ',end - start)
            result_df.to_csv(f'{result_dir}/welfare_result_summary.csv')
            individual_result_df.to_csv(f'{result_dir}/welfare_result_individual.csv')
            fig_opt.savefig(f'{result_dir}/price_opt_history.png')

if __name__ == '__main__':
    # Run all JRI cases with different outside option scenarios
    print("=== Running JRI Additional Data Analysis - Uninsured Case ===")
    main(oo_option='uninsured', oo_markup=None)
    
    print("=== Running JRI Additional Data Analysis with 0.5x Markup ===")
    main(oo_option='mc_times_markup', oo_markup=0.5)
    
    print("=== Running JRI Additional Data Analysis with 1.0x Markup ===")
    main(oo_option='mc_times_markup', oo_markup=1.0)
    
    print("=== Running JRI Additional Data Analysis with 1.5x Markup ===")
    main(oo_option='mc_times_markup', oo_markup=1.5)
    
    print("=== Running JRI Additional Data Analysis with 3.0x Markup ===")
    main(oo_option='mc_times_markup', oo_markup=3.0)
