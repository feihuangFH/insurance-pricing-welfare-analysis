# Quick Start Guide

## 5-Minute Setup

### Step 1: Install Dependencies (2 minutes)

```bash
# Navigate to package directory
cd reproducible_code_submission

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install packages
pip install -r requirements.txt
```

### Step 2: Verify Installation (1 minute)

```bash
python -c "import tensorflow; import pandas; import matplotlib; print('✓ All packages installed')"
```

### Step 3: Run Visualizations (2 minutes)

Using pre-computed results:

```bash
# French data visualizations
cd french_data
python visualize_welfare_french.py
python visualize_competition_french.py

# Additional data visualizations
cd ../additional_data
python visualize_welfare_additional.py
```

---

## What You Get

After running the quick start:

**French Data:**
- ✅ All welfare comparison plots
- ✅ 16 competition analysis plots
- ✅ Price distribution plots

**Additional Data:**
- ✅ Welfare comparison plots
- ✅ Price distribution plots

**Location:** Results saved in `results/french_data/` and `results/additional_data/`

---

## Next Steps

### To Reproduce Full Analysis

If you want to re-run the optimization (takes 3-5 hours):

```bash
# French data
cd french_data
python welfare_analysis_french.py

# Additional data
cd ../additional_data
python welfare_analysis_additional.py
```

### To Modify Parameters

See detailed READMEs:
- `french_data/README_FRENCH.md`
- `additional_data/README_ADDITIONAL.md`
- Main `README.md`

---

## Troubleshooting

**Problem:** Import errors  
**Solution:** `pip install -r requirements.txt`

**Problem:** Memory errors  
**Solution:** Close other applications, need 8GB+ RAM

**Problem:** Plots don't appear  
**Solution:** Check that you're in the correct directory

---

## System Requirements

- **Python:** 3.8+
- **RAM:** 8GB minimum (16GB recommended)
- **Storage:** 5GB for full results
- **Time:** 
  - Visualization only: ~10 minutes
  - Full reproduction: ~6-10 hours

---

## Contents Overview

```
reproducible_code_submission/
├── french_data/              ← French analysis + competition
├── additional_data/          ← Additional analysis (welfare only)
├── data/                     ← Input data files
├── results/                  ← Pre-computed results
├── shared_code/              ← Core utilities
├── README.md                 ← Full documentation
└── QUICKSTART.md            ← This file
```

---

**For detailed instructions, see `README.md`**

